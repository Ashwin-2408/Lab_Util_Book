import { BrowserRouter as Router, Route, Routes, Link } from "react-router-dom";
import Signup from "./components/Signup";
import Login from "./components/Login";

export default function App() {
  return (
    <Router>
      <div className="flex justify-center items-center h-screen flex-col">
        <nav className="mb-4">
          <Link to="/signup" className="mr-4 text-blue-500">Signup</Link>
          <Link to="/login" className="text-blue-500">Login</Link>
        </nav>
        <Routes>
          <Route path="/signup" element={<Signup />} />
          <Route path="/login" element={<Login />} />
        </Routes>
      </div>
    </Router>
  );
}